import math

# ring: (label, market_count, radius, duration_s, direction)
rings = [
    ("Middle East",    2,  118, 120,  1),
    ("Eastern Europe", 2,  168, 150, -1),
    ("CIS",            4,  222, 130,  1),
    ("Latin America",  6,  282, 170, -1),
    ("Asia Pacific",  15,  350, 145,  1),
    ("Africa",        17,  424, 190, -1),
]

CX, CY = 700, 560
W, H = 1400, 1120

out = []
out.append(f'<svg viewBox="0 0 {W} {H}" style="width:100%; height:100%; display:block; overflow:visible">')

for i, (label, n, r, dur, direction) in enumerate(rings):
    op = 0.16 + i * 0.035
    out.append(f'<circle cx="{CX}" cy="{CY}" r="{r}" fill="none" stroke="rgba(150,122,255,{op:.2f})" stroke-width="1.1"/>')

for i, (label, n, r, dur, direction) in enumerate(rings):
    cls = f"ring{i}"
    dots = []
    offset = i * 13
    for k in range(n):
        a = math.radians(offset + k * (360.0 / n))
        x = CX + r * math.cos(a)
        y = CY + r * math.sin(a)
        rad = 4.6 if i >= 4 else 5.2
        delay = (k * 0.37 + i * 0.6) % 6
        dots.append(
            f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rad}" fill="#7C63E8" '
            f'class="pulse" style="animation-delay:{delay:.2f}s"/>'
        )
    out.append(f'<g class="{cls}">' + "".join(dots) + "</g>")

# centre
out.append(f'<circle cx="{CX}" cy="{CY}" r="66" fill="#5B3FD2"/>')
out.append(f'<circle cx="{CX}" cy="{CY}" r="66" fill="none" stroke="rgba(150,122,255,0.45)" stroke-width="1.1" class="halo1"/>')
out.append(f'<circle cx="{CX}" cy="{CY}" r="66" fill="none" stroke="rgba(150,122,255,0.30)" stroke-width="1.1" class="halo2"/>')
out.append(
    f'<g transform="translate({CX-19},{CY-19})" stroke="#FFFFFF" stroke-width="1.6" fill="none" stroke-linecap="round">'
    f'<path d="M8 3c0 8 22 8 22 15s-22 6-22 15"/><path d="M30 3c0 8-22 8-22 15s22 6 22 15"/>'
    f'<path d="M11.5 11.5h15M11.5 26.5h15"/></g>'
)
out.append("</svg>")

css = []
for i, (label, n, r, dur, direction) in enumerate(rings):
    d = "normal" if direction > 0 else "reverse"
    css.append(
        f".ring{i} {{ transform-origin: {CX}px {CY}px; animation: spin {dur}s linear infinite {d}; }}"
    )
print("<!--ORBIT_CSS-->" + "\n".join(css) + "<!--/ORBIT_CSS-->")
print("".join(out))
