import glob, os, re

ARCS = '''<svg style="position:absolute; right:-260px; top:-380px; width:1100px; height:1100px; pointer-events:none" viewBox="0 0 1100 1100" fill="none">
  <circle cx="700" cy="400" r="640" stroke="rgba(150,122,255,0.16)" stroke-width="1.2"/>
  <circle cx="700" cy="400" r="470" stroke="rgba(150,122,255,0.30)" stroke-width="1.2"/>
  <circle cx="700" cy="400" r="330" stroke="rgba(150,122,255,0.22)" stroke-width="1.2"/>
</svg>'''

ARCS_BL = '''<svg style="position:absolute; left:-420px; bottom:-520px; width:900px; height:900px; pointer-events:none" viewBox="0 0 900 900" fill="none">
  <circle cx="380" cy="520" r="440" stroke="rgba(150,122,255,0.16)" stroke-width="1.2"/>
  <circle cx="380" cy="520" r="300" stroke="rgba(150,122,255,0.10)" stroke-width="1.2"/>
</svg>'''

MAP = open('map.svg').read()
MAP_DARK = open('map-dark.svg').read()
ORBIT = open('orbit.svg').read()
ORBIT_CSS = open('orbit.css').read()
PATHWAY = open('pathway.svg').read()
MAP_INK = open('map-ink.svg').read()
HERO_BLOCK = open('hero_block.html').read()
HERO_CSS = open('hero_css.txt').read()
WORLD = open('world.svg').read()
WORLD_LIGHT = open('world-light.svg').read()
LAND = open('land.svg').read()
LAND_LIGHT = open('land-light.svg').read()
DRIFT = open('drift.svg').read()
NIGHT = open('night_paths.json').read()

for src in sorted(glob.glob('*.src.html')):
    s = open(src).read()
    s = s.replace('<!--ARCS-->', ARCS).replace('<!--ARCS_BL-->', ARCS_BL)
    s = s.replace('<!--MAP-->', MAP).replace('<!--MAPDARK-->', MAP_DARK)
    s = s.replace('<!--ORBIT-->', ORBIT).replace('/*ORBIT_CSS*/', ORBIT_CSS)
    s = s.replace('<!--PATHWAY-->', PATHWAY).replace('<!--MAPINK-->', MAP_INK)
    s = s.replace('<!--PRACTICEHERO-->', HERO_BLOCK).replace('/*HEROCSS*/', HERO_CSS)
    s = s.replace('<!--WORLDMAP-->', WORLD).replace('<!--WORLDLIGHT-->', WORLD_LIGHT)
    s = s.replace('<!--LAND-->', LAND).replace('<!--LANDLIGHT-->', LAND_LIGHT)
    s = s.replace('<!--DRIFT-->', DRIFT)
    s = s.replace('/*NIGHTPATHS*/', NIGHT)
    out = src.replace('.src.html', '.dc.html')
    open(out, 'w').write(s)
    print('built', out, len(s))
