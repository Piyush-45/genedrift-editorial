import geopandas as gpd, warnings, json, re, sys
warnings.filterwarnings("ignore")

# RA / MAH / PV  — a=available, u=upcoming, n=not available
# Source: LF20 presentation, page 12 "Regional Delivery Capability"
DATA = [
 ("India","Asia Pacific","a","a","a"),      ("Sri Lanka","Asia Pacific","a","a","a"),
 ("Philippines","Asia Pacific","a","a","a"),("Myanmar","Asia Pacific","a","a","a"),
 ("Vietnam","Asia Pacific","a","a","a"),    ("Thailand","Asia Pacific","a","a","a"),
 ("Indonesia","Asia Pacific","a","n","a"),  ("Malaysia","Asia Pacific","a","a","a"),
 ("Singapore","Asia Pacific","a","a","a"),  ("Hong Kong","Asia Pacific","a","a","a"),
 ("Taiwan","Asia Pacific","a","a","a"),     ("Cambodia","Asia Pacific","a","u","a"),
 ("Brunei","Asia Pacific","a","n","n"),     ("Laos","Asia Pacific","a","n","n"),
 ("Pakistan","Asia Pacific","a","u","u"),

 ("Saudi Arabia","Middle East","a","a","a"),("United Arab Emirates","Middle East","u","u","u"),

 ("Kyrgyzstan","CIS","a","u","u"),          ("Uzbekistan","CIS","a","a","a"),
 ("Kazakhstan","CIS","u","u","u"),          ("Azerbaijan","CIS","a","n","n"),

 ("Russia","Eastern Europe","u","u","u"),   ("Ukraine","Eastern Europe","u","u","u"),

 ("Guatemala","Latin America","a","n","u"), ("Honduras","Latin America","a","n","u"),
 ("El Salvador","Latin America","a","n","u"),("Nicaragua","Latin America","a","n","u"),
 ("Chile","Latin America","u","n","u"),     ("Peru","Latin America","a","u","u"),

 ("Nigeria","Africa","a","a","a"),          ("Ghana","Africa","a","n","u"),
 ("Côte d'Ivoire","Africa","a","n","n"),    ("Burkina Faso","Africa","a","n","n"),
 ("Senegal","Africa","a","n","n"),          ("Togo","Africa","a","n","n"),
 ("Benin","Africa","a","n","n"),            ("Cameroon","Africa","a","n","n"),
 ("Dem. Rep. Congo","Africa","a","n","n"),  ("Chad","Africa","a","n","n"),
 ("Tanzania","Africa","a","a","u"),         ("Kenya","Africa","a","a","a"),
 ("Ethiopia","Africa","a","u","u"),         ("Uganda","Africa","a","u","u"),
 ("Zimbabwe","Africa","a","u","u"),         ("Madagascar","Africa","a","n","n"),
 ("South Africa","Africa","a","a","a"),
]

DISPLAY = {"Dem. Rep. Congo": "DR Congo", "Côte d'Ivoire": "Côte d’Ivoire",
           "United Arab Emirates": "United Arab Emirates"}

def slug(n):
    return re.sub(r"[^a-z0-9]+", "-", n.lower()).strip("-")

w = gpd.read_file(gpd.datasets.get_path("naturalearth_lowres"))
w = w[~w["name"].isin(["Antarctica", "Fr. S. Antarctic Lands"])].to_crs("+proj=robin")
minx, miny, maxx, maxy = w.total_bounds
W = 1160.0
sc = W / (maxx - minx)
H = (maxy - miny) * sc
w["geometry"] = w.geometry.simplify(11000)

by_name = {row["name"]: row.geometry for _, row in w.iterrows()}
missing = [n for n, *_ in DATA if n not in by_name]
print("no geometry for:", missing, file=sys.stderr)

def d_for(geom):
    parts = []
    polys = geom.geoms if geom.geom_type == "MultiPolygon" else [geom]
    for p in polys:
        if p.area * sc * sc < 3:
            continue
        pts = ["%.1f,%.1f" % ((x - minx) * sc, (maxy - y) * sc) for x, y in p.exterior.coords]
        parts.append("M" + "L".join(pts) + "Z")
    return "".join(parts)

op_names = {n for n, *_ in DATA}
out = ['<svg id="map" viewBox="0 0 %.0f %.0f" xmlns="http://www.w3.org/2000/svg">' % (W, H)]
out.append('<g class="base">')
for name, geom in by_name.items():
    if name in op_names:
        continue
    d = d_for(geom)
    if d:
        out.append('<path d="%s"/>' % d)
out.append("</g>")
out.append('<g class="live">')
for name, region, ra, mah, pv in DATA:
    if name not in by_name:
        continue
    d = d_for(by_name[name])
    if not d:
        continue
    out.append('<path class="mk" data-m="%s" d="%s"><title>%s</title></path>'
               % (slug(name), d, DISPLAY.get(name, name)))

# markets too small for 110m geometry — plot as markers
PTS = {"Singapore": (103.8, 1.35), "Hong Kong": (114.17, 22.3)}
import geopandas as _g
for nm, (lon, lat) in PTS.items():
    gs = _g.GeoSeries(_g.points_from_xy([lon], [lat]), crs=4326).to_crs("+proj=robin")
    px = (gs.iloc[0].x - minx) * sc; py = (maxy - gs.iloc[0].y) * sc
    out.append('<circle class="mk pin" data-m="%s" cx="%.1f" cy="%.1f" r="3.6"><title>%s</title></circle>'
               % (slug(nm), px, py, nm))
out.append("</g></svg>")

rows = [{"id": slug(n), "name": DISPLAY.get(n, n), "region": r,
         "ra": a, "mah": m, "pv": p} for n, r, a, m, p in DATA]

open("compare_map.svg", "w").write("".join(out))
open("compare_data.json", "w").write(json.dumps(rows, ensure_ascii=False, indent=0))
print("markets:", len(rows), "with geometry:", len(rows) - len(missing), file=sys.stderr)
