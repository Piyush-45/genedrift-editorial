import os, re, shutil

OUT = "share"
os.makedirs(OUT, exist_ok=True)

FILES = [
    ("Main.dc.html",           "01-route-a-homepage-desktop.html", "Genedrift — Homepage (Route A)",            False),
    ("Mobile.dc.html",         "02-route-a-homepage-mobile.html",  "Genedrift — Homepage, mobile (Route A)",    True),
    ("HeroE.dc.html",          "03-hero-orbit.html",               "Genedrift — Hero, Orbit",                   False),
    ("HeroF.dc.html",          "04-hero-pathway.html",             "Genedrift — Hero, Pathway",                 False),
    ("HeroG.dc.html",          "05-hero-regulatory-pulse.html",    "Genedrift — Hero, Regulatory Pulse",        False),
    ("PracticeHero.dc.html",   "06-route-b-hero.html",             "Genedrift — Hero (Route B)",                False),
    ("Practice.dc.html",       "07-route-b-homepage-desktop.html", "Genedrift — Homepage (Route B)",            False),
    ("PracticeMobile.dc.html", "08-route-b-homepage-mobile.html",  "Genedrift — Homepage, mobile (Route B)",    True),
    ("Drift.dc.html",          "09-concept-drift.html",            "Genedrift — Concept route",                 False),
]

def strip(src):
    s = open(src, encoding="utf-8").read()
    s = s.replace('<script src="./support.js"></script>', "")
    s = s.replace("<helmet>", "").replace("</helmet>", "")
    s = s.replace("<x-dc>", "").replace("</x-dc>", "")
    return s

for src, dst, title, mobile in FILES:
    s = strip(src)
    s = s.replace("<head>", '<head>\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n  <title>' + title + "</title>", 1)
    if mobile:
        s = s.replace("<body>", '<body style="background:#E9E9E6; display:flex; justify-content:center; padding:36px 0">', 1)
        s = s.replace('<div style="width: 390px;',
                      '<div style="box-shadow:0 24px 70px rgba(0,0,0,.16); border-radius:22px; overflow:hidden; width: 390px;', 1)
    else:
        s = s.replace("<body>", '<body style="margin:0">', 1)
    open(os.path.join(OUT, dst), "w", encoding="utf-8").write(s)
    print("wrote", dst, round(len(s) / 1024), "KB")
