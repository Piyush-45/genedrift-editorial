boxes = [
 # North America
 (48,72,-168,-60),(30,50,-125,-70),(15,30,-110,-86),(8,18,-92,-77),
 # Greenland
 (60,80,-50,-25),
 # South America
 (-5,12,-80,-50),(-20,-5,-75,-38),(-35,-20,-72,-50),(-52,-35,-73,-62),
 # Europe
 (40,60,-10,30),(54,70,5,40),(36,45,-9,28),
 # Africa
 (10,35,-16,34),(-10,12,8,42),(-34,-10,12,40),
 # Middle East
 (14,40,34,60),
 # Asia / CIS
 (44,72,40,140),(20,45,58,120),(6,25,70,90),(0,20,95,110),(30,45,124,145),
 # SE Asia
 (-9,6,95,125),
 # Australia / NZ
 (-38,-12,113,152),(-46,-35,166,179),
]

def is_land(lat, lon):
    for a,b,c,d in boxes:
        if a <= lat <= b and c <= lon <= d:
            return True
    return False

def is_focus(lat, lon):
    if -20 <= lon <= 52 and -35 <= lat <= 38: return True      # Africa
    if 33 <= lon <= 63 and 12 <= lat <= 42: return True        # Middle East
    if 25 <= lon <= 180 and 40 <= lat <= 78: return True       # CIS
    if lon >= 60 and -50 <= lat <= 60: return True             # APAC
    return False

W, H = 1040, 520
step = 11.0
cols = int(W/step); rows = int(H/step)
out = []
for r in range(rows):
    for c in range(cols):
        lon = -180 + (c + 0.5) * 360.0/cols
        lat = 80 - (r + 0.5) * 138.0/rows
        if not is_land(lat, lon): continue
        x = round(c*step + step/2, 1); y = round(r*step + step/2, 1)
        f = is_focus(lat, lon)
        fill = "#8B74FF" if f else "#574C90"
        rad = 3.1 if f else 2.6
        out.append(f'<circle cx="{x}" cy="{y}" r="{rad}" fill="{fill}"/>')
print(f'<svg viewBox="0 0 {W} {H}" width="100%" style="display:block">')
print("".join(out))
print("</svg>")
