"""
Six marker treatments, drawn on a real crop of the map so they can be
judged in context rather than as isolated swatches.
"""
import geopandas as gpd, warnings, sys
from shapely.ops import unary_union
from shapely.geometry import box

warnings.filterwarnings("ignore")

DATA = [
 ("India","a"),("Sri Lanka","a"),("Philippines","a"),("Myanmar","a"),("Vietnam","a"),
 ("Thailand","a"),("Indonesia","p"),("Malaysia","a"),("Taiwan","a"),("Cambodia","p"),
 ("Brunei","p"),("Laos","p"),("Pakistan","p"),("Saudi Arabia","a"),
 ("United Arab Emirates","p"),("Kyrgyzstan","p"),("Uzbekistan","a"),("Kazakhstan","p"),
 ("Azerbaijan","p"),("Nigeria","a"),("Ghana","p"),("Côte d'Ivoire","p"),
 ("Burkina Faso","p"),("Senegal","p"),("Togo","p"),("Benin","p"),("Cameroon","p"),
 ("Dem. Rep. Congo","p"),("Chad","p"),("Tanzania","a"),("Kenya","a"),("Ethiopia","p"),
 ("Uganda","p"),("Zimbabwe","p"),("Madagascar","p"),("South Africa","a"),
]
PTS = {"Singapore": (103.82, 1.35), "Hong Kong": (114.17, 22.32)}

w = gpd.read_file(gpd.datasets.get_path("naturalearth_lowres"))
w = w[~w["name"].isin(["Antarctica", "Fr. S. Antarctic Lands"])]
by_name = {r["name"]: r.geometry for _, r in w.iterrows()}

# same frame as the hero map
land = unary_union(list(w.geometry))
land_gs = gpd.GeoSeries([land], crs=w.crs).to_crs("+proj=robin")
minx, miny, maxx, maxy = land_gs.total_bounds
W = 1160.0
sc = W / (maxx - minx)

pts = []
for name, kind in DATA:
    if name in by_name:
        p = by_name[name].representative_point()
        pts.append((p.x, p.y, kind))
for nm, (lon, lat) in PTS.items():
    pts.append((lon, lat, "a"))

pt_gs = gpd.GeoSeries(gpd.points_from_xy([p[0] for p in pts], [p[1] for p in pts]),
                      crs=4326).to_crs("+proj=robin")
XY = [(((g.x - minx) * sc), ((maxy - g.y) * sc), k) for g, (_, _, k) in zip(pt_gs, pts)]

# crop tightly around Africa + Middle East + South and SE Asia
xs = [p[0] for p in XY]; ys = [p[1] for p in XY]
PAD = 34
vx0, vy0 = min(xs) - PAD, min(ys) - PAD
vw, vh = (max(xs) - min(xs)) + PAD * 2, (max(ys) - min(ys)) + PAD * 2

crop = box(minx + vx0 / sc, maxy - (vy0 + vh) / sc, minx + (vx0 + vw) / sc, maxy - vy0 / sc)
land_crop = land_gs.simplify(26000).iloc[0].intersection(crop)


def path_d(geom):
    parts = []
    polys = geom.geoms if geom.geom_type in ("MultiPolygon", "GeometryCollection") else [geom]
    for p in polys:
        if p.geom_type != "Polygon" or p.area * sc * sc < 6:
            continue
        ring = ["%.1f,%.1f" % ((x - minx) * sc, (maxy - y) * sc) for x, y in p.exterior.coords]
        parts.append("M" + "L".join(ring) + "Z")
    return "".join(parts)


LAND_D = path_d(land_crop)
LAND_FILL = "#C6BCE6"
INK, SOFT = "#241653", "#6E5CC4"


def marker(style, x, y, full):
    c = INK if full else SOFT
    if style == "solid":
        return '<circle cx="%.1f" cy="%.1f" r="%s" fill="%s"/>' % (x, y, 4.4 if full else 3.4, c)
    if style == "ring":
        return ('<circle cx="%.1f" cy="%.1f" r="%s" fill="none" stroke="%s" stroke-width="%s"/>'
                % (x, y, 4.2 if full else 3.2, c, 1.7 if full else 1.3))
    if style == "core":
        return ('<circle cx="%.1f" cy="%.1f" r="%s" fill="none" stroke="%s" stroke-opacity=".42" stroke-width="1"/>'
                '<circle cx="%.1f" cy="%.1f" r="%s" fill="%s"/>'
                % (x, y, 6.4 if full else 5.0, c, x, y, 2.4 if full else 1.9, c))
    if style == "halo":
        return ('<circle cx="%.1f" cy="%.1f" r="%s" fill="%s" fill-opacity=".16"/>'
                '<circle cx="%.1f" cy="%.1f" r="%s" fill="%s"/>'
                % (x, y, 9.5 if full else 7.5, c, x, y, 3.6 if full else 2.8, c))
    if style == "cross":
        L = 4.6 if full else 3.6
        return ('<path d="M%.1f %.1fH%.1fM%.1f %.1fV%.1f" stroke="%s" stroke-width="%s" stroke-linecap="round"/>'
                % (x - L, y, x + L, x, y - L, y + L, c, 1.6 if full else 1.2))
    if style == "diamond":
        s = 4.0 if full else 3.1
        return ('<path d="M%.1f %.1fL%.1f %.1fL%.1f %.1fL%.1f %.1fZ" fill="%s"/>'
                % (x, y - s, x + s, y, x, y + s, x - s, y, c))
    return ""


OPTIONS = [
    ("solid",   "Solid",         "What is there now. Reads as a placed pin — confident, a little heavy in the dense clusters."),
    ("ring",    "Open ring",     "Hollow centre. Lightest of the six and the clusters stop merging into blobs. Most precise."),
    ("core",    "Core and ring", "A survey mark: small solid centre, thin ring around it. Reads as a measured point, not a blob."),
    ("halo",    "Soft halo",     "Permanent low glow behind the dot. Warmest and most atmospheric — closest to the hover state."),
    ("cross",   "Crosshair",     "Two hairlines. Extremely restrained and technical; almost disappears at small sizes."),
    ("diamond", "Diamond",       "Rotated square. Geometric rather than organic, and distinct from every map-app default."),
]

# the landmass is defined once and referenced by each card
cards = ['<svg width="0" height="0" style="position:absolute" aria-hidden="true">'
         '<defs><path id="cropland" fill="%s" d="%s"/></defs></svg>' % (LAND_FILL, LAND_D)]
for key, title, note in OPTIONS:
    marks = "".join(marker(key, x, y, k == "a") for x, y, k in XY)
    cards.append(
        '<div class="dotcard">'
        '<div class="dotmap"><svg viewBox="%.0f %.0f %.0f %.0f" xmlns="http://www.w3.org/2000/svg">'
        '<use href="#cropland"/>%s</svg></div>'
        '<div class="dotmeta"><h4>%s</h4><p>%s</p></div>'
        '</div>' % (vx0, vy0, vw, vh, marks, title, note))

open("dot_options.html", "w").write("".join(cards))
print("wrote dot_options.html —", len(OPTIONS), "options,",
      len("".join(cards)) // 1024, "KB", file=sys.stderr)
