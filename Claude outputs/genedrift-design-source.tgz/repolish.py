"""
Route B polish pass — client review, 04 Sep.

1. Forest green -> brand purple #5B3FD2 throughout.
2. More whitespace: section padding up, gutters up.
3. Display type down a step (the client asked for "shorter fonts" — the
   underlying request is air, so type comes down AND padding goes up).

The market comparison table is removed by hand, not here.
"""
import re, sys

# --- 1. colour ---------------------------------------------------------------
COLOUR = {
    "#173D30": "#5B3FD2",   # forest accent      -> brand purple
    "#8FB6A4": "#B7A9EE",   # pale green tint    -> pale purple tint
    "#F0F3F1": "#F1EEFC",   # off-white on green -> off-white on purple
}

# --- 2. whitespace: vertical section rhythm ---------------------------------
PADDING = {
    "padding: 84px 58px 0": "padding: 132px 64px 0",
    "padding: 76px 58px 0": "padding: 124px 64px 0",
    "padding: 88px 58px 0": "padding: 136px 64px 0",
    "padding: 92px 58px 0": "padding: 140px 64px 0",
    "padding: 80px 58px 0": "padding: 128px 64px 0",
    "margin-top: 88px":     "margin-top: 128px",
    "margin-top: 84px":     "margin-top: 124px",
}

# --- 3. type scale: one step down on display sizes ---------------------------
TYPE = {
    "font-size: 66px": "font-size: 56px",
    "font-size: 46px": "font-size: 39px",
    "font-size: 40px": "font-size: 34px",
    "font-size: 30px": "font-size: 26px",
    "font-size: 26px": "font-size: 23px",
    "font-size: 24px": "font-size: 21px",
}

ORDER = [TYPE, PADDING, COLOUR]   # type first: padding rules mention px too


def polish(path):
    s = open(path, encoding="utf-8").read()
    before = s
    # type sizes: do them in one pass so 30->26 doesn't then hit 26->23
    def type_sub(m):
        return TYPE.get(m.group(0), m.group(0))
    s = re.sub(r"font-size: (?:66|46|40|30|26|24)px", type_sub, s)
    for table in (PADDING, COLOUR):
        for a, b in table.items():
            s = s.replace(a, b)
    if s != before:
        open(path, "w", encoding="utf-8").write(s)
    n = sum(before.count(a) for a in list(PADDING) + list(COLOUR))
    print(f"{path}: {n} spacing/colour swaps", file=sys.stderr)


for f in sys.argv[1:]:
    polish(f)
