"""
Borderless world map.

Every country polygon is dissolved into a single landmass, so NO international
boundary is drawn anywhere on the map. Markets are shown as points placed inside
their territory. Nothing on the map depicts, implies or disputes a border.

This removes the Kashmir / Aksai Chin / Arunachal Pradesh depiction problem for an
India-based company, and simultaneously removes Taiwan, Crimea, Western Sahara,
Palestine and Kosovo as boundary questions. Land is land.

LIGHT=1  -> light palette (white ground)
"""
import geopandas as gpd, warnings, os, sys, re
from shapely.ops import unary_union

warnings.filterwarnings("ignore")
LIGHT = os.environ.get("LIGHT") == "1"

# name, region, ra, mah, pv  (a=available, u=upcoming, n=not available)
DATA = [
 ("India","Asia Pacific","a","a","a"),      ("Sri Lanka","Asia Pacific","a","a","a"),
 ("Philippines","Asia Pacific","a","a","a"),("Myanmar","Asia Pacific","a","a","a"),
 ("Vietnam","Asia Pacific","a","a","a"),    ("Thailand","Asia Pacific","a","a","a"),
 ("Indonesia","Asia Pacific","a","n","a"),  ("Malaysia","Asia Pacific","a","a","a"),
 ("Singapore","Asia Pacific","a","a","a"),  ("Hong Kong","Asia Pacific","a","a","a"),
 ("Taiwan","Asia Pacific","a","a","a"),     ("Cambodia","Asia Pacific","a","u","a"),
 ("Brunei","Asia Pacific","a","n","n"),     ("Laos","Asia Pacific","a","n","n"),
 ("Pakistan","Asia Pacific","a","u","u"),
 ("Saudi Arabia","Middle East","a","a","a"),("United Arab Emirates","Middle East","u","u","u"),
 ("Kyrgyzstan","CIS","a","u","u"),          ("Uzbekistan","CIS","a","a","a"),
 ("Kazakhstan","CIS","u","u","u"),          ("Azerbaijan","CIS","a","n","n"),
 ("Russia","Eastern Europe","u","u","u"),   ("Ukraine","Eastern Europe","u","u","u"),
 ("Guatemala","Latin America","a","n","u"), ("Honduras","Latin America","a","n","u"),
 ("El Salvador","Latin America","a","n","u"),("Nicaragua","Latin America","a","n","u"),
 ("Chile","Latin America","u","n","u"),     ("Peru","Latin America","a","u","u"),
 ("Nigeria","Africa","a","a","a"),          ("Ghana","Africa","a","n","u"),
 ("Côte d'Ivoire","Africa","a","n","n"),    ("Burkina Faso","Africa","a","n","n"),
 ("Senegal","Africa","a","n","n"),          ("Togo","Africa","a","n","n"),
 ("Benin","Africa","a","n","n"),            ("Cameroon","Africa","a","n","n"),
 ("Dem. Rep. Congo","Africa","a","n","n"),  ("Chad","Africa","a","n","n"),
 ("Tanzania","Africa","a","a","u"),         ("Kenya","Africa","a","a","a"),
 ("Ethiopia","Africa","a","u","u"),         ("Uganda","Africa","a","u","u"),
 ("Zimbabwe","Africa","a","u","u"),         ("Madagascar","Africa","a","n","n"),
 ("South Africa","Africa","a","a","a"),
]


# standard UTC offsets, in hours (no DST modelling — these markets are mostly non-DST)
TZ = {
 "India":5.5,"Sri Lanka":5.5,"Philippines":8,"Myanmar":6.5,"Vietnam":7,"Thailand":7,
 "Indonesia":7,"Malaysia":8,"Singapore":8,"Hong Kong":8,"Taiwan":8,"Cambodia":7,
 "Brunei":8,"Laos":7,"Pakistan":5,"Saudi Arabia":3,"United Arab Emirates":4,
 "Kyrgyzstan":6,"Uzbekistan":5,"Kazakhstan":5,"Azerbaijan":4,"Russia":3,"Ukraine":2,
 "Guatemala":-6,"Honduras":-6,"El Salvador":-6,"Nicaragua":-6,"Chile":-3,"Peru":-5,
 "Nigeria":1,"Ghana":0,"Côte d'Ivoire":0,"Burkina Faso":0,"Senegal":0,"Togo":0,
 "Benin":1,"Cameroon":1,"Dem. Rep. Congo":1,"Chad":1,"Tanzania":3,"Kenya":3,
 "Ethiopia":3,"Uganda":3,"Zimbabwe":2,"Madagascar":3,"South Africa":2,
}

DISPLAY = {"Dem. Rep. Congo": "DR Congo", "Côte d'Ivoire": "Côte d’Ivoire",
           "United Arab Emirates": "UAE"}

# markets with no usable 110m polygon — placed by coordinate
PTS = {"Singapore": (103.82, 1.35), "Hong Kong": (114.17, 22.32)}

REGION_KEY = {"Asia Pacific": "apac", "Middle East": "me", "CIS": "cis",
              "Eastern Europe": "ee", "Latin America": "latam", "Africa": "afr"}

if LIGHT:
    LAND, DOT, DOT_SOFT = "#C6BCE6", "#241653", "#6E5CC4"
else:
    LAND, DOT, DOT_SOFT = "#2E1E68", "#B7A5FF", "#5B47A0"


def slug(n):
    return re.sub(r"[^a-z0-9]+", "-", n.lower()).strip("-")


w = gpd.read_file(gpd.datasets.get_path("naturalearth_lowres"))
w = w[~w["name"].isin(["Antarctica", "Fr. S. Antarctic Lands"])]
by_name = {row["name"]: row.geometry for _, row in w.iterrows()}

# --- market points, in lon/lat, BEFORE projecting ---
pts, missing = [], []
for name, region, ra, mah, pv in DATA:
    if name in PTS:
        lon, lat = PTS[name]
    elif name in by_name:
        p = by_name[name].representative_point()
        lon, lat = p.x, p.y
    else:
        missing.append(name)
        continue
    pts.append((name, region, ra, mah, pv, lon, lat))
print("no geometry for:", missing, file=sys.stderr)

# --- dissolve every country into ONE landmass: no border survives this ---
land = unary_union(list(w.geometry))
land_gs = gpd.GeoSeries([land], crs=w.crs).to_crs("+proj=robin")
pt_gs = gpd.GeoSeries(
    gpd.points_from_xy([p[5] for p in pts], [p[6] for p in pts]),
    crs=4326).to_crs("+proj=robin")

minx, miny, maxx, maxy = land_gs.total_bounds
W = 1160.0
sc = W / (maxx - minx)
H = (maxy - miny) * sc
land_simple = land_gs.simplify(9000).iloc[0]


def path_d(geom):
    parts = []
    polys = geom.geoms if geom.geom_type == "MultiPolygon" else [geom]
    for p in polys:
        if p.area * sc * sc < 2.5:
            continue
        ring = ["%.1f,%.1f" % ((x - minx) * sc, (maxy - y) * sc) for x, y in p.exterior.coords]
        parts.append("M" + "L".join(ring) + "Z")
    return "".join(parts)


out = ['<svg id="land" viewBox="0 0 %.0f %.0f" xmlns="http://www.w3.org/2000/svg" '
       'role="img" aria-label="World map showing the markets Genedrift operates in. '
       'No international boundaries are drawn.">' % (W, H)]
LAND_D = path_d(land_simple)
out.append('<defs>'
           '<clipPath id="landclip"><path d="%s"/></clipPath>'
           '<filter id="dusk" x="-15%%" y="-15%%" width="130%%" height="130%%">'
           '<feGaussianBlur stdDeviation="6"/></filter>'
           '</defs>' % LAND_D)
out.append('<path class="landmass" fill="%s" d="%s"/>' % (LAND, LAND_D))
# daylight band — clipped to the landmass so night falls on land, not on the page
out.append('<g clip-path="url(#landclip)">'
           '<path id="nightpath" d="" fill="%s" fill-opacity="%s" filter="url(#dusk)"/>'
           '</g>' % ("#241653" if LIGHT else "#05010F", ".23" if LIGHT else ".42"))

out.append('<g class="mkts">')
for (name, region, ra, mah, pv, _, _), g in zip(pts, pt_gs):
    x = (g.x - minx) * sc
    y = (maxy - g.y) * sc
    full = (ra == "a" and mah == "a" and pv == "a")
    out.append(
        '<g class="mk r-%s%s" data-m="%s" data-name="%s" data-region="%s" '
        'data-tz="%s" data-ra="%s" data-mah="%s" data-pv="%s">'
        '<circle class="halo" cx="%.1f" cy="%.1f" r="11"/>'
        '<circle class="dot" cx="%.1f" cy="%.1f" r="%s" fill="%s"/>'
        '<circle class="hit" cx="%.1f" cy="%.1f" r="14" fill="transparent"/>'
        '<title>%s</title></g>'
        % (REGION_KEY[region], " full" if full else "", slug(name),
           DISPLAY.get(name, name), region, TZ.get(name, 0), ra, mah, pv,
           x, y, x, y, "4.4" if full else "3.4",
           DOT if full else DOT_SOFT, x, y, DISPLAY.get(name, name)))
out.append("</g></svg>")

fn = "land-light.svg" if LIGHT else "land.svg"
open(fn, "w").write("".join(out))
print("wrote", fn, "— markets:", len(pts), "— borders drawn: 0", file=sys.stderr)
