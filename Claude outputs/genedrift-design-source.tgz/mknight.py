"""
Daylight terminator for the hero map.

Emits 24 hourly night-side polygons, projected through exactly the same
Robinson pipeline as mkland.py so they sit on the map pixel-for-pixel.
The page picks the polygon for the current UTC hour and re-checks every
few minutes.

Solar declination is computed for the build date. Over a week it moves
less than a degree, which at this opacity is invisible; a production
build would compute it client-side.
"""
import geopandas as gpd, warnings, math, json, datetime, sys
from shapely.geometry import Polygon
from shapely.ops import unary_union

warnings.filterwarnings("ignore")

# ---- same projection frame as mkland.py ----
w = gpd.read_file(gpd.datasets.get_path("naturalearth_lowres"))
w = w[~w["name"].isin(["Antarctica", "Fr. S. Antarctic Lands"])]
land = unary_union(list(w.geometry))
land_gs = gpd.GeoSeries([land], crs=w.crs).to_crs("+proj=robin")
minx, miny, maxx, maxy = land_gs.total_bounds
W = 1160.0
sc = W / (maxx - minx)
H = (maxy - miny) * sc

# ---- solar declination for today ----
today = datetime.date.today()
N = today.timetuple().tm_yday
decl = -23.44 * math.cos(math.radians(360.0 / 365.0 * (N + 10)))
print(f"build date {today}  day {N}  declination {decl:.2f}deg", file=sys.stderr)

if abs(decl) < 0.5:                       # near an equinox the curve degenerates
    decl = 0.5 if decl >= 0 else -0.5

LATS = 84.0                               # clip; Robinson gets extreme at the poles


def terminator_lat(lon, sub_lon):
    """Latitude of the day/night boundary at this longitude."""
    h = math.radians(lon - sub_lon)
    return math.degrees(math.atan(-math.cos(h) / math.tan(math.radians(decl))))


paths = []
for hour in range(24):
    sub_lon = 180.0 - 15.0 * hour         # subsolar longitude at this UTC hour
    ring = []
    lons = [-180 + i * 2.0 for i in range(181)]
    for lon in lons:
        lat = max(-LATS, min(LATS, terminator_lat(lon, sub_lon)))
        ring.append((lon, lat))
    # close the polygon along whichever pole is in darkness
    pole = -LATS if decl > 0 else LATS
    ring.append((180.0, pole))
    ring.append((-180.0, pole))

    poly = Polygon(ring)
    proj = gpd.GeoSeries([poly], crs=4326).to_crs("+proj=robin").iloc[0]

    pts = ["%.1f,%.1f" % ((x - minx) * sc, (maxy - y) * sc) for x, y in proj.exterior.coords]
    paths.append("M" + "L".join(pts) + "Z")

open("night_paths.json", "w").write(json.dumps(paths))
print(f"wrote night_paths.json — 24 hourly polygons, frame {W:.0f}x{H:.0f}", file=sys.stderr)
