import geopandas as gpd, warnings, math, random, sys
from shapely.geometry import Point
warnings.filterwarnings("ignore")
random.seed(7)

W, H = 1440.0, 700.0
N = 900

OPERATING = set("""India Sri Lanka Philippines Myanmar Vietnam Thailand Indonesia Malaysia Taiwan
Cambodia Brunei Laos Pakistan Nigeria Ghana Burkina Faso Senegal Togo Benin Cameroon Chad Tanzania
Kenya Ethiopia Uganda Zimbabwe Madagascar South Africa Saudi Arabia United Arab Emirates Kyrgyzstan
Uzbekistan Kazakhstan Azerbaijan Russia Ukraine Guatemala Honduras El Salvador Nicaragua Chile Peru""".split("\n"))
OPERATING = set(x.strip() for x in """India|Sri Lanka|Philippines|Myanmar|Vietnam|Thailand|Indonesia|Malaysia|Taiwan|Cambodia|Brunei|Laos|Pakistan|Nigeria|Ghana|Côte d'Ivoire|Burkina Faso|Senegal|Togo|Benin|Cameroon|Dem. Rep. Congo|Chad|Tanzania|Kenya|Ethiopia|Uganda|Zimbabwe|Madagascar|South Africa|Saudi Arabia|United Arab Emirates|Kyrgyzstan|Uzbekistan|Kazakhstan|Azerbaijan|Russia|Ukraine|Guatemala|Honduras|El Salvador|Nicaragua|Chile|Peru""".split("|"))

# ---------- STATE B : world ----------
w = gpd.read_file(gpd.datasets.get_path("naturalearth_lowres"))
w = w[~w["name"].isin(["Antarctica", "Fr. S. Antarctic Lands"])].to_crs("+proj=robin")
minx, miny, maxx, maxy = w.total_bounds
MW = W * 0.92
sc = MW / (maxx - minx)
MH = (maxy - miny) * sc
ox, oy = (W - MW) / 2.0, (H - MH) / 2.0 + 10

def proj(x, y):
    return (ox + (x - minx) * sc, oy + (maxy - y) * sc)

op_rows = w[w["name"].isin(OPERATING)]
other_rows = w[~w["name"].isin(OPERATING)]

def sample(rows, count):
    pts, areas = [], rows.geometry.area.tolist()
    total = sum(areas)
    for geom, a in zip(rows.geometry, areas):
        k = max(1, int(round(count * a / total)))
        b = geom.bounds
        got, tries = 0, 0
        while got < k and tries < k * 260:
            tries += 1
            px = random.uniform(b[0], b[2]); py = random.uniform(b[1], b[3])
            if geom.contains(Point(px, py)):
                pts.append(proj(px, py)); got += 1
    return pts

N_OP = 360
world_op = sample(op_rows, N_OP)
world_other = sample(other_rows, N - N_OP)
random.shuffle(world_op); random.shuffle(world_other)
world_op = (world_op * 4)[:N_OP]
world_other = (world_other * 4)[:N - N_OP]
particles = [(p, True) for p in world_op] + [(p, False) for p in world_other]
random.shuffle(particles)
B = [p for p, _ in particles]
ACC = [a for _, a in particles]
n = len(B)

# ---------- STATE A : double helix ----------
A = []
x0, x1 = W * 0.08, W * 0.92
cy = H / 2
amp = H * 0.26
turns = 3.4
for i in range(n):
    t = i / (n - 1)
    strand = i % 3
    ph = t * turns * 2 * math.pi
    x = x0 + t * (x1 - x0)
    if strand == 2:            # rungs
        k = (i // 3) % 5 / 5.0
        ya = cy + amp * math.sin(ph)
        yb = cy + amp * math.sin(ph + math.pi)
        A.append((x, ya + (yb - ya) * k))
    else:
        off = 0 if strand == 0 else math.pi
        A.append((x, cy + amp * math.sin(ph + off)))

# ---------- STATE C : coverage skyline (46 markets x 14 rows) ----------
COLS, ROWS = 46, 14
gw, gh = W * 0.82, H * 0.66
gx, gy = (W - gw) / 2, (H - gh) / 2 + 4
cellw = gw / (COLS - 1); cellh = gh / (ROWS - 1)

# capability score per market: 3 = RA+MAH+PV, 2 = partial, 1 = RA only
scores = ([3] * 20) + ([2] * 14) + ([1] * 12)
random.shuffle(scores)
heights = [max(3, round(sc_ / 3 * (ROWS - 2))) for sc_ in scores]

acc_slots, base_slots = [], []
for c in range(COLS):
    x = gx + c * cellw
    for r in range(ROWS):
        y = gy + (ROWS - 1 - r) * cellh
        (acc_slots if r < heights[c] else base_slots).append((x, y))
random.shuffle(base_slots)

acc_idx = [i for i in range(n) if ACC[i]]
oth_idx = [i for i in range(n) if not ACC[i]]
Cpos = [None] * n
for k, i in enumerate(acc_idx):
    Cpos[i] = acc_slots[k % len(acc_slots)]
for k, i in enumerate(oth_idx):
    Cpos[i] = base_slots[k % len(base_slots)]
C = Cpos

# ---------- emit ----------
KT = "0;0.19;0.30;0.49;0.60;0.79;0.90;1"
SPL = ";".join([".45 0 .15 1"] * 7)
out = [f'<svg viewBox="0 0 {W:.0f} {H:.0f}" style="width:100%;height:auto;display:block;overflow:visible">']
for i in range(n):
    ax, ay = A[i]; bx, by = B[i]; cx_, cy_ = C[i]
    acc = ACC[i]
    fill = "#8B6DFF" if acc else "#3E3A5C"
    r = 1.9 if acc else 1.5
    j = (i % 17) * 0.0035
    mid = [0.19,0.30,0.49,0.60,0.79,0.90]
    kt = "0;" + ";".join(f"{v+j:.4f}" for v in mid) + ";1"
    vx = f"{ax:.1f};{ax:.1f};{bx:.1f};{bx:.1f};{cx_:.1f};{cx_:.1f};{ax:.1f};{ax:.1f}"
    vy = f"{ay:.1f};{ay:.1f};{by:.1f};{by:.1f};{cy_:.1f};{cy_:.1f};{ay:.1f};{ay:.1f}"
    out.append(
      f'<circle cx="{ax:.1f}" cy="{ay:.1f}" r="{r}" fill="{fill}">'
      f'<animate attributeName="cx" values="{vx}" keyTimes="{kt}" dur="30s" repeatCount="indefinite" calcMode="spline" keySplines="{SPL}"/>'
      f'<animate attributeName="cy" values="{vy}" keyTimes="{kt}" dur="30s" repeatCount="indefinite" calcMode="spline" keySplines="{SPL}"/>'
      f'</circle>')
out.append("</svg>")
print("".join(out))
print(f"particles={n} accent={sum(ACC)}", file=sys.stderr)
