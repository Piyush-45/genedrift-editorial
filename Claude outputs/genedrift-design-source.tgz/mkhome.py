# Assemble the Route A homepage around the locked Regulatory Pulse hero.
import re, sys

main = open("Main.src.html").read()
hero = open("HeroG.src.html").read()

# ---------- pull the hero apart ----------
hcss   = hero[hero.index("<style>")+7 : hero.index("</style>")]
hbody  = hero[hero.index("</helmet>")+9 : hero.index("<script>")]
js0    = hero.rindex("<script>")
hjs    = hero[js0 : hero.index("</script>", js0)+9]
assert "REGION_COUNT" in hjs
assert 'height: 780px' in hbody and 'landwrap' in hbody

# ---------- 1. merge the hero's CSS into the page's helmet ----------
keep = [l for l in hcss.splitlines()
        if not re.match(r'\s*(body \{|a \{|a:hover|p \{|h1, h2, h3)', l)]
main = main.replace("    /*ORBIT_CSS*/", "\n".join(keep), 1)

# ---------- 2. swap the orbit hero for the pulse hero ----------
a = main.index("  <!-- ==================== HERO")
b = main.index("  <!-- ==================== EXPLORE")
main = main[:a] + "  <!-- ==================== HERO (locked: Regulatory Pulse) ==================== -->\n" \
       + hbody.strip() + "\n\n" + main[b:]

# ---------- 3. drop the search box from Explore ----------
s0 = main.index('      <div style="display: flex; align-items: center; gap: 10px; background: #F4F5F7; border-radius: 10px; padding: 7px 7px 7px 20px; width: 560px')
s1 = main.index("</div>\n    </div>", s0) + len("</div>\n")
main = main[:s0] + '''      <div style="display: flex; align-items: center; gap: 8px; font-size: 15px; font-weight: 600; color: #5B3FD2; padding-bottom: 8px; flex-shrink: 0">
        All guided journeys <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#5B3FD2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
      </div>
''' + main[s1:]
assert 'Search a market, capability' not in main

# ---------- 4. Global Presence: the hero already carries the map ----------
g0 = main.index("    <div style=\"display: flex; gap: 28px; align-items: stretch; margin-top: 44px\">")
g1 = main.index("    <div style=\"display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 16px; margin-top: 28px\">")

REGIONS = [
 ("Asia Pacific", "15", "India · Sri Lanka · Philippines · Myanmar · Vietnam · Thailand · Indonesia · Malaysia · Singapore · Hong Kong · Taiwan · Cambodia · Brunei · Laos · Pakistan"),
 ("Africa", "17", "Nigeria · Kenya · South Africa · Tanzania · Ethiopia · Uganda · Zimbabwe · Ghana · Côte d’Ivoire · Senegal · Burkina Faso · Togo · Benin · Cameroon · DR Congo · Chad · Madagascar"),
 ("Latin America", "06", "Peru · Chile · Guatemala · Honduras · El Salvador · Nicaragua"),
 ("CIS", "04", "Uzbekistan · Kazakhstan · Kyrgyzstan · Azerbaijan"),
 ("Middle East", "02", "Saudi Arabia · United Arab Emirates"),
 ("Eastern Europe", "02", "Russia · Ukraine"),
]
cards = []
for name, n, mkts in REGIONS:
    cards.append('''      <div style="background: #FFFFFF; border-radius: 18px; padding: 30px 32px 28px; display: flex; flex-direction: column">
        <div style="display: flex; align-items: baseline; justify-content: space-between">
          <h3 style="font-size: 23px; letter-spacing: -0.03em">%s</h3>
          <span style="font-size: 30px; font-weight: 700; letter-spacing: -0.04em; color: #5B3FD2">%s</span>
        </div>
        <div style="height: 1px; background: #ECEDF1; margin-top: 18px"></div>
        <p style="margin-top: 18px; font-size: 15px; line-height: 1.75; color: #6B6B6B; flex-grow: 1">%s</p>
        <div style="display: flex; align-items: center; gap: 7px; margin-top: 22px; font-size: 14.5px; font-weight: 600; color: #5B3FD2">View region <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#5B3FD2" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></div>
      </div>''' % (name, n, mkts))

presence = '''    <div style="display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 20px; margin-top: 48px">
%s
    </div>

    <div style="display: flex; align-items: center; gap: 22px; margin-top: 20px; background: #241653; color: #FFFFFF; border-radius: 18px; padding: 28px 34px">
      <div style="flex-grow: 1">
        <div style="font-size: 20px; font-weight: 600; letter-spacing: -0.02em">Forty-six markets, one accountable team</div>
        <div style="margin-top: 8px; font-size: 15.5px; line-height: 1.6; color: #B8AFDF; max-width: 720px">Regulatory Affairs, MAH representation and Pharmacovigilance, delivered by in-country specialists on record with the authority. Live status for every market is on the map above.</div>
      </div>
      <div style="background: #5B3FD2; color: #FFFFFF; font-size: 15.5px; font-weight: 600; padding: 14px 26px; border-radius: 9px; flex-shrink: 0">Speak to an expert</div>
    </div>

''' % ("\n".join(cards))

main = main[:g0] + presence + main[g1:]

# ---------- 5. no comparison tool anywhere ----------
main = main.replace('          <span style="font-size: 14.5px; color: #B8AFDF">Compare Markets</span>\n', '')
assert 'Compare Markets' not in main

# ---------- 6. hero script at the end ----------
main = main.replace("</x-dc>", hjs + "\n</x-dc>", 1)

open("Home.src.html", "w").write(main)
print("wrote Home.src.html", len(main))
