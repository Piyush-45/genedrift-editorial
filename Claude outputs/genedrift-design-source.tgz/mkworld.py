import geopandas as gpd, warnings, json, sys, os
LIGHT = os.environ.get("LIGHT") == "1"
BASE   = "#D3D7E0" if LIGHT else "#3B2F72"
STROKE = "#F4F5F7" if LIGHT else "#241653"
ACTIVE = "#5B3FD2" if LIGHT else "#7C63E8"
GRAT   = "0.09" if LIGHT else "0.10"
warnings.filterwarnings("ignore")

REGIONS = {
  "apac":   ["India","Sri Lanka","Philippines","Myanmar","Vietnam","Thailand","Indonesia",
             "Malaysia","Taiwan","Cambodia","Brunei","Laos","Pakistan","Singapore"],
  "africa": ["Nigeria","Ghana","Côte d'Ivoire","Burkina Faso","Senegal","Togo","Benin",
             "Cameroon","Dem. Rep. Congo","Chad","Tanzania","Kenya","Ethiopia","Uganda",
             "Zimbabwe","Madagascar","South Africa"],
  "me":     ["Saudi Arabia","United Arab Emirates"],
  "cis":    ["Kyrgyzstan","Uzbekistan","Kazakhstan","Azerbaijan"],
  "ee":     ["Russia","Ukraine"],
  "latam":  ["Guatemala","Honduras","El Salvador","Nicaragua","Chile","Peru"],
}
ORDER = ["apac","africa","me","cis","ee","latam"]

w = gpd.read_file(gpd.datasets.get_path("naturalearth_lowres"))
w = w[~w["name"].isin(["Antarctica", "Fr. S. Antarctic Lands"])]
w = w.to_crs("+proj=robin")

W = 1700.0
minx, miny, maxx, maxy = w.total_bounds
scale = W / (maxx - minx)
H = (maxy - miny) * scale

w["geometry"] = w.geometry.simplify(14000)

lookup = {}
missing = []
for key, names in REGIONS.items():
    for n in names:
        if n not in set(w["name"]):
            missing.append(n)
        lookup[n] = key
print("<!-- missing:", ", ".join(missing), "-->", file=sys.stderr)

def ring_to_d(coords):
    pts = []
    for x, y in coords:
        px = (x - minx) * scale
        py = (maxy - y) * scale
        pts.append(f"{px:.1f},{py:.1f}")
    return "M" + "L".join(pts) + "Z"

def geom_to_d(geom):
    parts = []
    polys = geom.geoms if geom.geom_type == "MultiPolygon" else [geom]
    for poly in polys:
        if poly.area * scale * scale < 4:
            continue
        parts.append(ring_to_d(poly.exterior.coords))
    return "".join(parts)

groups = {k: [] for k in ORDER}
base = []
for _, row in w.iterrows():
    d = geom_to_d(row.geometry)
    if not d:
        continue
    key = lookup.get(row["name"])
    (groups[key] if key else base).append(d)

out = []
out.append(f'<svg viewBox="0 0 {W:.0f} {H:.0f}" style="width:100%; height:auto; display:block; overflow:visible">')

# graticule
out.append('<g stroke="#5B3FD2" stroke-width="0.8" fill="none" opacity="%s">' % GRAT)
for lat in range(-60, 90, 30):
    pts = []
    for lon in range(-180, 181, 5):
        pts.append((lon, lat))
    g = gpd.GeoSeries(gpd.points_from_xy([p[0] for p in pts], [p[1] for p in pts]), crs=4326).to_crs("+proj=robin")
    d = "M" + "L".join(f"{(p.x-minx)*scale:.1f},{(maxy-p.y)*scale:.1f}" for p in g)
    out.append(f'<path d="{d}"/>')
for lon in range(-180, 181, 30):
    pts = [(lon, la) for la in range(-60, 86, 5)]
    g = gpd.GeoSeries(gpd.points_from_xy([p[0] for p in pts], [p[1] for p in pts]), crs=4326).to_crs("+proj=robin")
    d = "M" + "L".join(f"{(p.x-minx)*scale:.1f},{(maxy-p.y)*scale:.1f}" for p in g)
    out.append(f'<path d="{d}"/>')
out.append('</g>')

out.append(f'<g fill="{BASE}" stroke="{STROKE}" stroke-width="0.7" stroke-linejoin="round">')
for d in base:
    out.append(f'<path d="{d}"/>')
out.append('</g>')

for i, key in enumerate(ORDER):
    out.append(f'<g class="rgn r-{key}" fill="{ACTIVE}" stroke="{STROKE}" stroke-width="0.7" stroke-linejoin="round" style="animation-delay:{i*2.6:.1f}s">')
    for d in groups[key]:
        out.append(f'<path d="{d}"/>')
    out.append('</g>')

# region anchors for pulse rings
anchors = {}
for key in ORDER:
    sel = w[w["name"].isin(REGIONS[key])]
    if len(sel) == 0:
        continue
    c = sel.geometry.union_all().centroid if hasattr(sel.geometry, "union_all") else sel.geometry.unary_union.centroid
    anchors[key] = ((c.x - minx) * scale, (maxy - c.y) * scale)

out.append('<g fill="none" stroke="%s">' % ("#5B3FD2" if LIGHT else "#A794FF"))
for i, key in enumerate(ORDER):
    if key not in anchors:
        continue
    x, y = anchors[key]
    out.append(f'<circle class="pulse" cx="{x:.1f}" cy="{y:.1f}" r="6" style="animation-delay:{i*2.6:.1f}s"/>')
    out.append(f'<circle class="pulse2" cx="{x:.1f}" cy="{y:.1f}" r="6" style="animation-delay:{i*2.6+0.9:.1f}s"/>')
    out.append(f'<circle class="core" cx="{x:.1f}" cy="{y:.1f}" r="3.4" fill="#8B74FF" stroke="none" style="animation-delay:{i*2.6:.1f}s"/>')
out.append('</g>')

out.append('</svg>')
print("".join(out))
