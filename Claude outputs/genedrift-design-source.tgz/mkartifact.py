import re, io

src = open("HeroG.dc.html").read()

# strip the design-canvas wrapper: keep <helmet> contents + everything after it
h0 = src.index("<helmet>") + len("<helmet>")
h1 = src.index("</helmet>")
head = src[h0:h1]

b0 = src.index("</helmet>") + len("</helmet>")
b1 = src.rindex("</x-dc>")
body = src[b0:b1]

page = []
page.append("<title>Genedrift — Regulatory Pulse hero</title>")
page.append(head)
page.append("""
<style>
  html, body { background: #FFFFFF; }
  .fitwrap { width: 100%; overflow: hidden; }
  .fit { width: 1440px; transform-origin: top left; }
</style>
""")
page.append('<div class="fitwrap"><div class="fit">')
page.append(body)
page.append('</div></div>')
page.append("""
<script>
function fitAll() {
  document.querySelectorAll(".fitwrap").forEach(function (wrap) {
    var fit = wrap.querySelector(".fit");
    var k = Math.min(1, wrap.clientWidth / 1440);
    fit.style.transform = "scale(" + k + ")";
    wrap.style.height = (fit.scrollHeight * k) + "px";
  });
}
window.addEventListener("resize", fitAll);
window.addEventListener("load", fitAll);
fitAll();
</script>
""")

open("pulse-hero-artifact.html", "w").write("\n".join(page))
print("wrote pulse-hero-artifact.html", len("\n".join(page)) // 1024, "KB")
