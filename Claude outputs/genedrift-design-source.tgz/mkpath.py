import math

# two cubic segments, chained
P = [
    ((-60, 372), (300, 372), (470, 300), (740, 252)),
    ((740, 252), (1020, 204), (1180, 168), (1500, 112)),
]

def bez(p, t):
    (x0, y0), (x1, y1), (x2, y2), (x3, y3) = p
    u = 1 - t
    x = u*u*u*x0 + 3*u*u*t*x1 + 3*u*t*t*x2 + t*t*t*x3
    y = u*u*u*y0 + 3*u*u*t*y1 + 3*u*t*t*y2 + t*t*t*y3
    return x, y

# sample whole path, arc-length parameterise
samples = []
for si, p in enumerate(P):
    steps = 400
    for i in range(steps + 1):
        if si == 1 and i == 0:
            continue
        samples.append(bez(p, i / steps))

lengths = [0.0]
for i in range(1, len(samples)):
    dx = samples[i][0] - samples[i-1][0]
    dy = samples[i][1] - samples[i-1][1]
    lengths.append(lengths[-1] + math.hypot(dx, dy))
total = lengths[-1]

def point_at(frac):
    target = frac * total
    for i in range(1, len(lengths)):
        if lengths[i] >= target:
            return samples[i]
    return samples[-1]

stages = [
    ("01", "Regulatory Strategy"),
    ("02", "Dossier Preparation"),
    ("03", "eCTD Publishing"),
    ("04", "Submission &amp; Authority"),
    ("05", "Approval"),
    ("06", "Lifecycle &amp; PV"),
]

d = (f'M{P[0][0][0]},{P[0][0][1]} C{P[0][1][0]},{P[0][1][1]} {P[0][2][0]},{P[0][2][1]} {P[0][3][0]},{P[0][3][1]} '
     f'C{P[1][1][0]},{P[1][1][1]} {P[1][2][0]},{P[1][2][1]} {P[1][3][0]},{P[1][3][1]}')

out = ['<svg viewBox="0 0 1440 420" style="width:100%; height:420px; display:block; overflow:visible">']
out.append(f'<path d="{d}" fill="none" stroke="rgba(150,122,255,0.22)" stroke-width="1.1"/>')
out.append(f'<path class="draw" d="{d}" fill="none" stroke="#7C63E8" stroke-width="2.4" stroke-linecap="round" '
           f'style="stroke-dasharray:{total:.0f}; stroke-dashoffset:{total:.0f}"/>')

fracs = [0.11, 0.268, 0.426, 0.584, 0.742, 0.90]
for i, (num, label) in enumerate(stages):
    x, y = point_at(fracs[i])
    delay = 0.55 + i * 0.34
    out.append(f'<g class="node" style="animation-delay:{delay:.2f}s">')
    out.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="17" fill="#241653" stroke="#7C63E8" stroke-width="1.4"/>')
    out.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="6" fill="#7C63E8"/>')
    out.append(f'<line x1="{x:.1f}" y1="{y-17:.1f}" x2="{x:.1f}" y2="{y-52:.1f}" stroke="rgba(150,122,255,0.35)" stroke-width="1"/>')
    out.append(f'<text x="{x:.1f}" y="{y-90:.1f}" text-anchor="middle" fill="#9C92C9" '
               f'font-family="Archivo, Helvetica, Arial, sans-serif" font-size="13" font-weight="700" letter-spacing="1.6">{num}</text>')
    out.append(f'<text x="{x:.1f}" y="{y-66:.1f}" text-anchor="middle" fill="#FFFFFF" '
               f'font-family="Archivo, Helvetica, Arial, sans-serif" font-size="16" font-weight="600">{label}</text>')
    out.append('</g>')

out.append('</svg>')
print(f'<!--LEN:{total:.0f}-->')
print(''.join(out))
